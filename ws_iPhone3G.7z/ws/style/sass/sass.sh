#!/bin/bash
sass --watch baseStyles.scss:../baseStyles.css